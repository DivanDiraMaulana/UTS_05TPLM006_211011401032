package com.example.uts

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
